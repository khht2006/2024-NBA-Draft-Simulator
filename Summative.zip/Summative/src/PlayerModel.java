
 
import java.util.List;
 
import javax.swing.table.AbstractTableModel;
 

public class PlayerModel extends AbstractTableModel {
	
    public static final int COLUMN_RANK      = 0;
    public static final int COLUMN_NAME    = 1;
    public static final int COLUMN_HEIGHT     = 2;
    public static final int COLUMN_WEIGHT     = 3;
    public static final int COLUMN_COLLEGESTATUS     = 4;
    public static final int COLUMN_PPG     = 5;
    public static final int COLUMN_RPG    = 6;
    public static final int COLUMN_APG   = 7;
    public static final int COLUMN_BPG     = 8;
    public static final int COLUMN_SPG     = 9;
    
     
    private String[] columnNames = {"Rank", "Name", "Height","Weight", "College Status", "PPG", "RPG", "APG", "BPG", "SPG"};
    private List<Player> listPlayers;
     
    
    public PlayerModel(List<Player> listPlayers) {
        this.listPlayers = listPlayers;
    }
    	
 
    @Override
    public int getColumnCount() {
        return columnNames.length;
    }
 
    @Override
    public int getRowCount() {
        return listPlayers.size();
    }
     
    @Override
    public String getColumnName(int columnIndex) {
        return columnNames[columnIndex];
    }
     
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (listPlayers.isEmpty()) {
            return Object.class;
        }
        return getValueAt(0, columnIndex).getClass();
    }
 
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Player player = listPlayers.get(rowIndex);
        Object returnValue = null;
         
        switch (columnIndex) {
        case COLUMN_RANK:
            returnValue = player.getRank();
            break;
        case COLUMN_NAME:
            returnValue = player.getName() + " - " + player.getPosition() + " | " + player.getTeam();
            break;
        case COLUMN_HEIGHT:
            returnValue = player.getHeight();
            break;
        case COLUMN_WEIGHT:
            returnValue = Integer.toString(player.getWeight()) + " lbs";
            break;
        case COLUMN_COLLEGESTATUS:
            returnValue = player.getCollegeStatus();
            break;
        case COLUMN_PPG:
            returnValue = Double.toString(player.getPPG()) + " PTS";
            break;
        case COLUMN_RPG:
        	returnValue = Double.toString(player.getRPG()) + " REB";
            break;
        case COLUMN_APG:
        	returnValue = Double.toString(player.getAPG()) + " AST";
            break;
        case COLUMN_BPG:
        	returnValue = Double.toString(player.getBPG()) + " BLK";
            break;
        case COLUMN_SPG:
        	returnValue = Double.toString(player.getSPG()) + " STL";
            break;
        default:
            throw new IllegalArgumentException("Invalid column index");
        }
         
        return returnValue;
    }


  
    
 
}