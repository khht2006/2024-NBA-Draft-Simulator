import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
 

public class BigBoard extends JFrame {
	//Declare class variables needed throughout the program
	private JPanel contentPane;
    private JTable table;
    private JTable table2;
    private JTable table3;
    private DefaultTableModel model;
    List<Player> allPlayers = createListPlayers();
	List<Player> sortedPlayers = new ArrayList<>();
	List<JCheckBox> positionCheckboxes = new ArrayList<>();
    
    
    public BigBoard() {
    	//Creating the title and size of the screen
    	setTitle("2024 NBA Draft Big Board");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		contentPane = new JPanel();
		// Get the screen dimensions
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        //Set preferred size to the dimensions of the screen
		contentPane.setPreferredSize(new Dimension(screenSize.width-5, screenSize.height-50));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		//Creating the title of the frame and customizing layout
		JLabel lblNewLabel = new JLabel("2024 NBA Draft Big Board");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
		
		//Filtering players by pg
		JCheckBox pg = new JCheckBox("PG");
		pg.setBounds(8, 0, 50, 25);
		
		//Filtering players by sg
		JCheckBox sg = new JCheckBox("SG");
		sg.setBounds(68, 0, 50, 25);
		
		//Filtering players by sf
		JCheckBox sf = new JCheckBox("SF");
		sf.setBounds(128, 0, 50, 25);
		
		//Filtering players by pf
		JCheckBox pf = new JCheckBox("PF");
		pf.setBounds(188, 0, 50, 25);
		
		//Filtering players by c
		JCheckBox c = new JCheckBox("C");
		c.setBounds(248, 0, 50, 25);
		
		
		//Add checkboxes to the frame
		positionCheckboxes.add(pg);
		positionCheckboxes.add(sg);
		positionCheckboxes.add(sf);
		positionCheckboxes.add(pf);
		positionCheckboxes.add(c);
		
	
		contentPane.add(pg);
		contentPane.add(sg);
		contentPane.add(sf);
		contentPane.add(pf);
		contentPane.add(c);
		
		
		//Creating the list of players and the table model
        List<Player> listPlayers = createListPlayers();
        
        
        PlayerModel playerModel = new PlayerModel(listPlayers);
        
        //lblNewLabel.setBackground(Color.white);
        //lblNewLabel.setOpaque(true);
        model = new DefaultTableModel();
       
        
        //Set table color to red and add a means of sorting
        table = new JTable(playerModel);
        Color redColor = new Color(255, 50, 50);
        table.getTableHeader().setBackground(redColor);
        table.setAutoCreateRowSorter(true);
        
       
        // Set row height to accommodate larger images
        table.setRowHeight(35); // Adjust the value as needed

        // Set column width to accommodate larger images
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(1).setPreferredWidth(35); // Adjust the value as needed

         
        
        //Adding the column titles
        model.addColumn("Rank");
        model.addColumn("Stats Are Per 36 mins");
        model.addColumn("Tier");
        model.addColumn("Name/Position");
        model.addColumn("Height");
        model.addColumn("Weight");
        model.addColumn("Age/College Status");
        model.addColumn("Points");
        model.addColumn("Rebounds");
        model.addColumn("Assists");
        model.addColumn("Blocks");
        model.addColumn("Steals");
        
        
        
        //Importing the data into the table model
        for (Player player: listPlayers) {
        	model.addRow(new Object[] {
        		player.getRank(),
        		player.getIcon(),
        		"<> " + player.getTier(),
        		player.getName() + " | " + player.getPosition(),
        		player.getHeight(),
        		player.getWeight() + " lbs",
        		player.getAge() + " yrs | " + player.getCollegeStatus(),
        		player.getPPG() + " PTS",
        		player.getRPG() + " REB",
        		player.getAPG() + " AST",
        		player.getBPG() + " BLK",
        		player.getSPG() + " STL",
        		
        	});
        }
        
        
        
        table.setModel(model);
        table.getColumnModel().getColumn(1).setCellRenderer(new ImageRender());
        
        
        //Adding item listeners for the checkboxes
        pg.addItemListener(new ItemListener() {
        	@Override
        	public void itemStateChanged(ItemEvent e) {
        		if (pg.isSelected()) {
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			loadPlayers(sortedPlayers);
        			sortedPlayers.clear();
        		}
        		else {
        			int count = 0;
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					count++;
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			if(count == 0) {
    					loadPlayers(allPlayers);
    				}
    				else {
    					loadPlayers(sortedPlayers);
    				}
        			sortedPlayers.clear();
        		}
        	}
        });
        
        sg.addItemListener(new ItemListener() {
        	@Override
        	public void itemStateChanged(ItemEvent e) {
        		if (sg.isSelected()) {
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			loadPlayers(sortedPlayers);
        			sortedPlayers.clear();
        		}
        		else {
        			int count = 0;
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					count++;
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			if(count == 0) {
    					loadPlayers(allPlayers);
    				}
    				else {
    					loadPlayers(sortedPlayers);
    				}
        			sortedPlayers.clear();
        		}
        	}
        });
        
        sf.addItemListener(new ItemListener() {
        	@Override
        	public void itemStateChanged(ItemEvent e) {
        		if (sf.isSelected()) {
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			loadPlayers(sortedPlayers);
        			sortedPlayers.clear();
        		}
        		else {
        			int count = 0;
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					count++;
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			if(count == 0) {
    					loadPlayers(allPlayers);
    				}
    				else {
    					loadPlayers(sortedPlayers);
    				}
        			sortedPlayers.clear();
        		}
        	}
        });
        
        pf.addItemListener(new ItemListener() {
        	@Override
        	public void itemStateChanged(ItemEvent e) {
        		if (pf.isSelected()) {
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			loadPlayers(sortedPlayers);
        			sortedPlayers.clear();
        		}
        		else {
        			int count = 0;
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					count++;
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			if(count == 0) {
    					loadPlayers(allPlayers);
    				}
    				else {
    					loadPlayers(sortedPlayers);
    				}
        			sortedPlayers.clear();
        		}
        	}
        });
        
        
        c.addItemListener(new ItemListener() {
        	@Override
        	public void itemStateChanged(ItemEvent e) {
        		if (c.isSelected()) {
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			loadPlayers(sortedPlayers);
        			sortedPlayers.clear();
        		}
        		else {
        			int count = 0;
        			for (JCheckBox checkbox : positionCheckboxes) {
        				if (checkbox.isSelected()) {
        					count++;
        					checkFilter(checkbox.getText(), "position");
        				}
        			}
        			if(count == 0) {
    					loadPlayers(allPlayers);
    				}
    				else {
    					loadPlayers(sortedPlayers);
    				}
        			sortedPlayers.clear();
        		}
        	}
        });
        
 
        // Sorting the tables
        //Default sorting by the rank of the players
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(sorter);
        List<RowSorter.SortKey> sortKeys = new ArrayList<>();
        
        int columnRank = 0; 
        int columnIndexToSort = 0;
      
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));
        //Making sure the rank is sorted by integers instead of strings
        sorter.setComparator(columnRank, new IntegerComparator());
        
         
        sorter.setSortKeys(sortKeys);
        sorter.sort();
        
        
        //Sorting select columns by numbers instead of by strings
        int columnHeight = 4;
        int columnPPG = 6;
        int columnRPG = 7;
        int columnAPG = 8;
        int columnBPG = 9;
        int columnSPG = 10;
        
        
        sorter.setComparator(columnPPG, new MixedTypeComparator());
        sorter.setComparator(columnRPG, new MixedTypeComparator());
        sorter.setComparator(columnAPG, new MixedTypeComparator());
        sorter.setComparator(columnBPG, new MixedTypeComparator());
        sorter.setComparator(columnSPG, new MixedTypeComparator());
        //Make sure height sorting is correct
        sorter.setComparator(columnHeight, new HeightComparator());
        
        
        //Disable sorting of the icons column
    	sorter.setSortable(1, false);
         
        
        
 
        add(new JScrollPane(table), BorderLayout.CENTER);
        
        
        
        // Create a menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create a "View" menu
        JMenu viewMenu = new JMenu("More");

        // Create menu items for "Mock Draft" and "Past Draft Results"
        JMenuItem lotterySimulatorMenuItem = new JMenuItem("Lottery Simulator");
        JMenuItem mockDraftMenuItem = new JMenuItem("Mock Draft");
        JMenuItem pickOddsMenuItem = new JMenuItem("Pick Odds");
        JMenuItem pastDraftResultsMenuItem = new JMenuItem("Past Draft Results");

        // Add action listeners to the menu items
        
        lotterySimulatorMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openLotterySimulator();
            }
        });
        
        mockDraftMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
            	openMockDraft();
            }
        });
        
        
        pickOddsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openPickOdds();
            }
        });

        pastDraftResultsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Past Draft Results" frame
                openPastDraftResults();
            }
        });

        // Add menu items to the "View" menu
        viewMenu.add(lotterySimulatorMenuItem);
        viewMenu.add(mockDraftMenuItem);
        viewMenu.add(pickOddsMenuItem);
        viewMenu.add(pastDraftResultsMenuItem);

        // Add the "View" menu to the menu bar
        menuBar.add(Box.createHorizontalGlue());
        menuBar.add(viewMenu);

        // Set the menu bar for the JFrame
        setJMenuBar(menuBar);
 
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        
        
        

    }
    
    //Creating lists of players for each tier
    public List<Player> createListPlayers() {
        List<Player> listPlayers = new ArrayList<>();
 
        // Player Data
        Player Alexandre_Sarr = new Player(1, "Resources/france.png", 1, "Alexandre Sarr", "PF/C", "Perth", "7-1", 217, "International", 18.7, 18.7, 9.1, 2.0, 2.4, 0.9);
        Player Nikola_Topic = new Player(2, "Resources/serbia.png", 1, "Nikola Topic", "PG", "Red Star", "6-6", 201, "International", 18.4, 19.1, 4.2, 7.1, 0.2, 1.1);
        Player Zaccharie_Risacher = new Player(3, "Resources/france.png", 1, "Zaccharie Risacher", "SF", "JL Bourg", "6-9", 204, "International", 18.7, 18.0, 5.8, 1.6, 0.7, 1.5);
        Player JaKobe_Walter = new Player(4, "Resources/baylor.png", 1, "Ja'Kobe Walter", "SG", "Baylor", "6-5", 180, "Freshman", 19.3, 20.5, 5.5, 2.1, 0.2, 1.7);
        Player Ron_Holland = new Player(5, "Resources/gleague.png", 1, "Ron Holland", "SF/PF", "G League", "6-8", 200, "G League", 18.5, 20.9, 7.7, 3.1, 1.1, 2.6);
        Player Matas_Buzelis = new Player(6, "Resources/gleague.png", 1, "Matas Buzelis", "SF", "G League", "6-11", 195, "G League", 19.2, 16.0, 6.6, 2.2, 1.8, 1.5);
        Player Reed_Sheppard = new Player(7, "Resources/kentucky.png", 2, "Reed Sheppard", "PG/SG", "Kentucky", "6-3", 187, "Freshman", 19.5, 17.1, 6.4, 5.9, 1.3, 3.8);
        Player Rob_Dillingham = new Player(8, "Resources/kentucky.png", 2, "Rob Dillingham", "PG", "Kentucky", "6-3", 176, "Freshman", 19.0, 22.4, 6.0, 7.0, 0.1, 2.5);
        Player Isaiah_Collier = new Player(9, "Resources/usc.png", 2, "Isaiah Collier", "PG", "USC", "6-4", 205, "Freshman", 19.3, 19.3, 3.2, 5.4, 0.2, 1.6);
        Player Cody_Williams = new Player(10, "Resources/colorado.png", 2, "Cody Williams", "SF", "Colorado", "6-8", 185, "Freshman", 19.1, 18.0, 4.6, 2.6, 0.4, 1.1);
        Player Donovan_Clingan = new Player(11, "Resources/uconn.png", 2, "Donovan Clingan", "C", "UConn", "7-2", 265, "Sophomore", 19.9, 24.2, 10.9, 2.2, 3.5, 0.9);
        Player Stephon_Castle = new Player(12, "Resources/uconn.png", 3, "Stephon Castle", "PG/SG", "UConn", "6-6", 190, "Freshman", 19.2, 15.1, 7.4, 5.3, 0.9, 1.8);
        Player Kyle_Filipowski = new Player(13, "Resources/duke.png", 3, "Kyle Filipowski", "C", "Duke", "7-0", 248, "Sophomore", 20.2, 21.4, 10.6, 3.6, 2.4, 1.5);
        Player Tidjane_Salaun = new Player(14, "Resources/france.png", 3, "Tidjane Salaun", "SF", "Cholet Basket", "6-9", 203, "International", 18.4, 15.1, 5.1, 1.3, 0.3, 2.1);
        Player Ryan_Dunn = new Player(15, "Resources/virginia.png", 3, "Ryan Dunn", "SF", "Virginia", "6-8", 216, "Sophomore", 21.0, 13.6, 9.3, 1.3, 2.9, 2.7);
        Player Tyrese_Proctor = new Player(16, "Resources/duke.png", 3, "Tyrese Proctor", "PG", "Duke", "6-5", 183, "Sophomore", 19.8, 12.4, 3.6, 6.0, 0.3, 1.1);
        Player Kelel_Ware = new Player(17, "Resources/indiana.png", 3, "Kel'el Ware", "C", "Indiana", "7-0", 223, "Sophomore", 19.7, 17.0, 10.8, 2.0, 1.8, 1.0);
        Player Tyler_Smith = new Player(18, "Resources/gleague.png", 3, "Tyler Smith", "PF/SF", "G League", "6-11", 224, "G League", 19.2, 21.7, 8.7, 2.5, 1.6, 1.5);
        Player Kevin_McCullar = new Player(19, "Resources/kansas.png", 3, "Kevin McCullar", "SG", "Kansas", "6-6", 210, "Senior", 22.8, 20.9, 7.1, 4.7, 0.7, 1.6);
        Player Bobi_Clintman = new Player(20, "Resources/sweden.png", 3, "Bobi Clintman", "SF/PF", "Cairns", "6-10", 225, "International", 20.8, 17.9, 7.9, 1.7, 1.0, 1.9);
        
        
        //Adding players to the player list
        listPlayers.add(Alexandre_Sarr);
        listPlayers.add(Nikola_Topic);
        listPlayers.add(Zaccharie_Risacher);
        listPlayers.add(JaKobe_Walter);
        listPlayers.add(Ron_Holland);
        listPlayers.add(Matas_Buzelis);
        listPlayers.add(Reed_Sheppard);
        listPlayers.add(Rob_Dillingham);
        listPlayers.add(Isaiah_Collier);
        listPlayers.add(Cody_Williams);
        listPlayers.add(Donovan_Clingan);
        listPlayers.add(Stephon_Castle);
        listPlayers.add(Kyle_Filipowski);
        listPlayers.add(Tidjane_Salaun);
        listPlayers.add(Ryan_Dunn);
        listPlayers.add(Tyrese_Proctor);
        listPlayers.add(Kelel_Ware);
        listPlayers.add(Tyler_Smith);
        listPlayers.add(Kevin_McCullar);
        listPlayers.add(Bobi_Clintman);
        
        
        return listPlayers;
    }
    
    
    
    
    
    //Method to filter out players by position
    private void checkFilter(String filter, String filterType) {
    	
    	if (filterType.equals("position")) {
    		for (Player player: allPlayers) {
    			if (player.getPosition().contains(filter)&&!sortedPlayers.contains(player)) {
    				sortedPlayers.add(player);
    			}
    		}
    	}
        
    }
    
    //Method to load all players into the table
    private void loadPlayers(List<Player> Players) {
    	model.getDataVector().clear();
    	model.fireTableDataChanged();
    	
    	for (Player player: Players) {
        	model.addRow(new Object[] {
        		player.getRank(),
        		player.getIcon(),
        		"<> " + player.getTier(),
        		player.getName() + " | " + player.getPosition(),
        		player.getHeight(),
        		player.getWeight() + " lbs",
        		player.getAge() + " yrs | " + player.getCollegeStatus(),
        		player.getPPG() + " PTS",
        		player.getRPG() + " REB",
        		player.getAPG() + " AST",
        		player.getBPG() + " BLK",
        		player.getSPG() + " STL",
        		
        	});
        }
    	
    	table.setModel(model);
        table.getColumnModel().getColumn(1).setCellRenderer(new ImageRender());
    }
    
    
    
    //Running the frame created in the ApplicationData class
    public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApplicationData.bigBoard = new BigBoard();
					ApplicationData.bigBoard.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
    
    
    //Displaying the icon images
    public class ImageRender extends DefaultTableCellRenderer {
    	@Override
    	public Component getTableCellRendererComponent (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    		String icon = value.toString();
    		ImageIcon imageIcon = new ImageIcon (new ImageIcon(icon).getImage().getScaledInstance(28, 28, Image.SCALE_DEFAULT));
    		return new JLabel(imageIcon);
    	}
    }
    
    //Handling sorting of the cases where the data contains numbers and string i.e 16.0PTS>9.8PTS
    //Extracting the numeric value of the string
    private static class MixedTypeComparator implements Comparator<Object> {
        @Override
        public int compare(Object o1, Object o2) {
            Double value1 = extractNumericValue(o1.toString());
            Double value2 = extractNumericValue(o2.toString());

            return Double.compare(value1, value2);
        }

        private Double extractNumericValue(String s) {
            // Extract numeric value using a regex
            Pattern pattern = Pattern.compile("\\d+\\.\\d+");
            Matcher matcher = pattern.matcher(s);

            if (matcher.find()) {
                return Double.parseDouble(matcher.group());
            }

            return 0.0;
        }
    }
    
    //Convert height to inches for comparison
    public class HeightComparator implements Comparator<String> {
        @Override
        public int compare(String height1, String height2) {
            String[] parts1 = height1.split("-");
            String[] parts2 = height2.split("-");

            int feet1 = Integer.parseInt(parts1[0]);
            int inches1 = Integer.parseInt(parts1[1]);
            int feet2 = Integer.parseInt(parts2[0]);
            int inches2 = Integer.parseInt(parts2[1]);

            // Convert feet to inches and add to inches
            int totalInches1 = feet1 * 12 + inches1;
            int totalInches2 = feet2 * 12 + inches2;

            // Compare total inches
            return Integer.compare(totalInches1, totalInches2);
        }
    }
    
    //Comparing integer values instead of string values
    public class IntegerComparator implements Comparator<Object> {
        @Override
        public int compare(Object o1, Object o2) {
            Integer value1 = extractIntegerValue(o1.toString());
            Integer value2 = extractIntegerValue(o2.toString());

            return Integer.compare(value1, value2);
        }
        //Extract the integer value from the string
        private Integer extractIntegerValue(String s) {
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                return 0; // Return 0 if parsing fails
            }
        }
    }
    //Open the LS page if clicked from menu
    private void openLotterySimulator() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.lotterySimulator == null) {
					ApplicationData.lotterySimulator = new LotterySimulator();
					}
				ApplicationData.lotterySimulator.setVisible(true);
				ApplicationData.bigBoard.setVisible(false);
            }
        });
    }
    
    //Open the MD page if clicked from menu
    private void openMockDraft() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.mockDraft == null) {
					ApplicationData.mockDraft = new MockDraft();
					}
				ApplicationData.mockDraft.setVisible(true);
				ApplicationData.bigBoard.setVisible(false);
            }
        });
    }
    
    //Open the PO page if clicked from menu
    private void openPickOdds() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.pickOdds == null) {
					ApplicationData.pickOdds = new PickOdds();
					}
				ApplicationData.pickOdds.setVisible(true);
				ApplicationData.bigBoard.setVisible(false);
            }
        });
    }
    
    //Open the PDS page if clicked from menu
    private void openPastDraftResults() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.pastDraftResults == null) {
					ApplicationData.pastDraftResults = new PastDraftResults();
					}
				ApplicationData.pastDraftResults.setVisible(true);
				ApplicationData.bigBoard.setVisible(false);
            }
        });
    }

    
    
}
