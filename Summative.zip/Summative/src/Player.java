public class Player {
	private int rank;
	private String icon;
	private int tier;
    private String name;
    private String position;
    private String team;
    private String height;
    private int weight;
    private String collegeStatus;
    private double age;
    private double ppg;
    private double rpg;
    private double apg;
    private double bpg;
    private double spg;
    
    
    public Player (int rank, String icon, int tier, String name, String position, String team, String height, int weight, String collegeStatus, double age, double ppg,  double rpg, double apg, double bpg, double spg) {
        this.rank = rank;
        this.icon = icon;
        this.tier = tier;
    	this.name = name;
        this.position = position;
        this.team = team;
        this.height = height;
        this.weight = weight;
        this.collegeStatus = collegeStatus;
        this.age = age;
        this.ppg = ppg;
        this.rpg = rpg;
        this.apg = apg;
        this.bpg = bpg;
        this.spg = spg;
        
    }
    
    
    public int getRank() {
    	return this.rank;
    }
    public String getIcon() {
    	return this.icon;
    }
    public int getTier() {
    	return this.tier;
    }
    public String getName() {
    	return this.name;
    }
    public String getPosition() {
    	return this.position;
    }
    public String getTeam() {
    	return this.team;
    }
    public String getHeight() {
    	return this.height;
    }
    public int getWeight() {
    	return this.weight;
    }
    public String getCollegeStatus() {
    	return this.collegeStatus;
    }
    public double getAge() {
    	return this.age;
    }
    public double getPPG() {
    	return this.ppg;
    }
    public double getRPG() {
    	return this.rpg;
    }
    public double getAPG() {
    	return this.apg;
    }
    public double getBPG() {
    	return this.bpg;
    }
    public double getSPG() {
    	return this.spg;
    }
    
    
}
