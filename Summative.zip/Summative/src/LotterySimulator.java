import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class LotterySimulator extends JFrame {
	
	//Create the table models, progress bar, and thread
    private DefaultTableModel model;
    private List<Team> teams;
    private JTable table;

    public static JProgressBar progressBar;

    private int count = 0;
    private Thread myTimerThread;

    public LotterySimulator() {
    	//Setting the size of the screen
        setTitle("2024 NBA Draft Lottery Simulator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1550, 820);
        setLocationRelativeTo(null);
        
        //Creating the title of the frame using a label
      	JLabel lblNewLabel = new JLabel("2024 NBA Draft Lottery Simulator");
      	lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
      	lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
      	

        

        // Create the table model
        model = new DefaultTableModel();
        teams = createListTeams();
        table = new JTable(model);
        Color orangeColor = new Color(255, 140, 10);
        table.getTableHeader().setBackground(orangeColor);

        
        //Adding the column titles
        model.addColumn("PICK");
        model.addColumn("SEED");
        model.addColumn("");
        model.addColumn("TEAM");
        model.addColumn("RECORD");
        model.addColumn("WIN%");
        model.addColumn("GB");
        model.addColumn("STREAK");
        model.addColumn("L10");
        model.addColumn("TOP 4");
        model.addColumn("#1 OVR");
        
        
        
        
        //Importing the data into the table model
        for (Team team: teams) {
         	model.addRow(new Object[] {
         		teams.indexOf(team)+1,
         		"#" + team.getPick(), //index 0
         		team.getIcon(),
         		team.getName(),
         		team.getRecord(),
         		team.getWinPercentage(),
         		team.getGB(),
         		team.getStreak(),
         		team.getL10(),
         		team.getTop4()+"%",
         		team.getTop1()+"%" 
         	
         	});
         }

        
        table.setModel(model);
        table.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());

        progressBar = new JProgressBar(0, 100);
        progressBar.setValue(0);



        // Create the Simulate button
        JButton simulateButton = new JButton("Simulate Lottery");
        simulateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread1 = new Thread() {
                    public void run() {
                    	resetProgressBar();
                        progressBar.setValue(0);
                        simulateLottery();
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException ee) {
                            ee.printStackTrace();
                        }
                    }
//                    }
                };
                thread1.start();
            }
        });
        
        // Create the Reset button
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetTable();
                resetProgressBar();
                progressBar.setValue(0);
            }
        });

        // Create a panel to hold the button
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(simulateButton);
        buttonPanel.add(resetButton); // Add the Reset button
        buttonPanel.add(progressBar, BorderLayout.PAGE_END);

        // Create the main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Set the main panel
        setContentPane(mainPanel);
        mainPanel.add(lblNewLabel, BorderLayout.NORTH);


        
        // Set row height to accommodate larger images
        table.setRowHeight(30); // Adjust the value as needed

        // Set column width to accommodate larger images
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(1).setPreferredWidth(30); // Adjust the value as needed
        
        
        // Create a menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create a "View" menu
        JMenu viewMenu = new JMenu("More");

        // Create menu items for "Mock Draft" and "Past Draft Results"
        JMenuItem mockDraftMenuItem = new JMenuItem("Mock Draft");
        JMenuItem bigBoardMenuItem = new JMenuItem("Big Board");
        JMenuItem pickOddsMenuItem = new JMenuItem("Pick Odds");
        JMenuItem pastDraftResultsMenuItem = new JMenuItem("Past Draft Results");

        // Add action listeners to the menu items
        mockDraftMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
            	openMockDraft();
            }
        });
        
        
        bigBoardMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openBigBoard();
            }
        });
        pickOddsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openPickOdds();
            }
        });

        pastDraftResultsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Past Draft Results" frame
                openPastDraftResults();
            }
        });

        // Add menu items to the "View" menu
        viewMenu.add(bigBoardMenuItem);
        viewMenu.add(mockDraftMenuItem);
        viewMenu.add(pickOddsMenuItem);
        viewMenu.add(pastDraftResultsMenuItem);

        // Add the "View" menu to the menu bar
        menuBar.add(Box.createHorizontalGlue());
        menuBar.add(viewMenu);

        // Set the menu bar for the JFrame
        setJMenuBar(menuBar);
    }
    
    //Method to simulate the lottery 
    private void simulateLottery() {
        long totalTime = 1;
        List<Team> randomTeams = randomLottery();
        model.getDataVector().clear();
        int index = 1;
        
        //Calculate movement results for the lottery
        for (Team team : randomTeams) {
            String pickSymbol;

            int pickDifference = team.getPick() - (randomTeams.indexOf(team) + 1);

            if (pickDifference > 0) {
                pickSymbol = "\u2191"; // Better pick than seed
            } else if (pickDifference < 0) {
                pickSymbol = "\u2193"; // Worse pick than seed
            } else {
                pickSymbol = "-"; // Same pick as seed
            }
            //Load the teams back into the table
            model.addRow(new Object[] {
                    index,
                    pickSymbol + " " + (pickSymbol.equals("-") ? "-" : Math.abs(pickDifference)), // Display the difference as a positive number
                    team.getIcon(),
                    team.getName(),
                    team.getRecord(),
                    team.getWinPercentage(),
                    team.getGB(),
                    team.getStreak(),
                    team.getL10(),
                    team.getTop4() + "%",
                    team.getTop1() + "%"
            });
            index++;
        }
        
        //Create swing worker to increment the progress bar smoothly
        SwingWorker<Void, Integer> worker = new SwingWorker<Void, Integer>() {
            @Override
            protected Void doInBackground() throws Exception {
                int count = 0;
                while (count <= totalTime * 10) {
                    int percentage = (int) ((double) count / (totalTime * 10) * 100);
                    publish(percentage);
                    Thread.sleep(100);
                    count++;
                }
                return null;
            }

            @Override
            protected void process(List<Integer> chunks) {
                if (!chunks.isEmpty()) {
                    int percentage = chunks.get(chunks.size() - 1);
                    progressBar.setValue(percentage);
                    progressBar.setStringPainted(true);

                    if (percentage == 100) {
                        progressBar.setString(randomTeams.get(0).getName() + "!");
                    }
                }
            }
        };

        worker.execute();
    }
    
    
    //Distribute the picks to the lottery teams randomly
    public List<Team> randomLottery() {
    		HashMap<Integer, Team> top4ToTeam = new HashMap();
    		Integer count = 0;
    		List<Integer> allData = new ArrayList<>();
    		List<Team> randomTeams = new ArrayList<>();
    		
    		for(Team team: teams) {
    			top4ToTeam.put(count, team);
    			for(int i = 0; i<team.getTop1()*10; i++) {
    				allData.add(count);
    			}
    			count++;
    		}
    		Random rand = new Random();
    		for(int i = 0; i<4; i++) {
    			int randIndex = rand.nextInt(allData.size());
    			int numAtRand = allData.get(randIndex);
    			Team pickedTeam = top4ToTeam.get(numAtRand);
    			randomTeams.add(pickedTeam);
    			allData.removeAll(List.of(numAtRand));
    		}
    		for(Team team: teams) {
    			if(!randomTeams.contains(team)) {
    				randomTeams.add(team);
    			}
    		}
            return randomTeams;
    }
    
    //Creating the list of teams
    public List<Team> createListTeams() {
        List<Team> listTeams = new ArrayList<>();
 
        // Team Data
        Team Detroit = new Team(1, "Resources/detroit.png", "Detroit", "3-33", 0.083, 0, "Lost 4", "1-9", 52.1, 14.0);
        Team San_Antonio = new Team(2, "Resources/sanAntonio.png", "San Antonio", "5-30", 0.143, 2.5, "Lost 5", "1-9", 52.1, 14.0);
        Team Washington = new Team(3, "Resources/washington.png", "Washington", "6-29", 0.171, 3.5, "Lost 4", "2-8", 52.1, 14.0);
        Team Charlotte = new Team(4, "Resources/charlotte.png", "Charlotte", "8-25", 0.242, 6.5, "Lost 1", "1-9", 48.1, 12.5);
        Team Portland = new Team(5, "Resources/portland.png", "Portland", "10-25", 0.286, 7.5, "Won 1", "4-6", 42.1, 10.5);
        Team Memphis = new Team(6, "Resources/memphis.png", "Memphis", "13-23", 0.361, 10.0, "Won 2", "6-4", 37.2, 9.0);
        Team Atlanta = new Team(7, "Resources/atlanta.png", "Atlanta", "14-21", 0.400, 11.5, "Lost 2", "4-6", 31.9, 7.5);
        Team Toronto = new Team(8, "Resources/toronto.png", "Toronto", "15-21", 0.417, 12.0, "Won 1", "4-6", 26.3, 6.0);
        Team Brooklyn = new Team(9, "Resources/brooklyn.png", "Brooklyn", "16-21", 0.432, 12.5, "Lost 1", "3-7", 17.3, 3.8);
        Team Chicago = new Team(10, "Resources/chicago.png", "Chicago", "16-21", 0.432, 12.5, "Won 1", "6-4", 16.9, 3.7);
        Team Utah = new Team(11, "Resources/utah.png", "Utah", "17-20", 0.459, 13.5, "Won 1", "7-3", 9.4, 2.0);
        Team Golden_State = new Team(12, "Resources/goldenState.png", "Golden State", "17-19", 0.472, 14.0, "Lost 1", "5-5", 7.1, 1.5);
        Team Los_Angeles_Lakers = new Team(13, "Resources/losAngelesLakers.png", "Los Angeles Lakers", "18-19", 0.486, 14.5, "Won 1", "3-7", 4.8, 1.0);
        Team Phoenix = new Team(14, "Resources/phoenix.png", "Phoenix", "19-17", 0.528, 16.0, "Lost 1", "5-5", 2.4, 0.5);
        
        
        //Adding Teams to the Team list
        listTeams.add(Detroit);
        listTeams.add(San_Antonio);
        listTeams.add(Washington);
        listTeams.add(Charlotte);
        listTeams.add(Portland);
        listTeams.add(Memphis);
        listTeams.add(Atlanta);
        listTeams.add(Toronto);
        listTeams.add(Brooklyn);
        listTeams.add(Chicago);
        listTeams.add(Utah);
        listTeams.add(Golden_State);
        listTeams.add(Los_Angeles_Lakers);
        listTeams.add(Phoenix);
        
        return listTeams;
    }
    
    //Displaying the icon images
    public class ImageRender extends DefaultTableCellRenderer {
    	@Override
    	public Component getTableCellRendererComponent (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    		String icon = value.toString();
    		ImageIcon imageIcon = new ImageIcon (new ImageIcon(icon).getImage().getScaledInstance(25, 25, Image.SCALE_DEFAULT));
    		return new JLabel(imageIcon);
    	}
    }
    
    //To reset the table to its original state
    private void resetTable() {
        model.getDataVector().clear();
        int index = 1;
        for (Team team : teams) {
            model.addRow(new Object[]{
                index,
                "#" + team.getPick(),
                team.getIcon(),
                team.getName(),
                team.getRecord(),
                team.getWinPercentage(),
                team.getGB(),
                team.getStreak(),
                team.getL10(),
                team.getTop4(),
                team.getTop1()
            });
            index++;
        }
        table.setModel(model);
        table.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());
    }
    
    //Method to reset the progress bar
    private void resetProgressBar() {
        progressBar.setValue(0);
        progressBar.setString(""); // Clear any text in the progress bar
    }
    
   
    //Method to run the item selected from the menu
    private void openBigBoard() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.bigBoard == null) {
					ApplicationData.bigBoard = new BigBoard();
					}
				ApplicationData.bigBoard.setVisible(true);
				ApplicationData.lotterySimulator.setVisible(false);
            }
        });
    }
    
    //Method to run the item selected from the menu
    private void openMockDraft() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.mockDraft == null) {
					ApplicationData.mockDraft = new MockDraft();
					}
				ApplicationData.mockDraft.setVisible(true);
				ApplicationData.lotterySimulator.setVisible(false);
            }
        });
    }
    
    //Method to run the item selected from the menu
    private void openPickOdds() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.pickOdds == null) {
					ApplicationData.pickOdds = new PickOdds();
					}
				ApplicationData.pickOdds.setVisible(true);
				ApplicationData.lotterySimulator.setVisible(false);
            }
        });
    }
    
    //Method to run the item selected from the menu
    private void openPastDraftResults() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.pastDraftResults == null) {
					ApplicationData.pastDraftResults = new PastDraftResults();
					}
				ApplicationData.pastDraftResults.setVisible(true);
				ApplicationData.lotterySimulator.setVisible(false);
            }
        });
    }
    
    //Running the frame
    public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApplicationData.lotterySimulator = new LotterySimulator();
					ApplicationData.lotterySimulator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}