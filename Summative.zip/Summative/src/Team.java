public class Team {
	private int pick;
	private String icon;
	private String name;
	private String record;
    private double winPercentage;
    private double gb;
    private String streak;
    private String L10;
    private double top4;
    private double top1;
    
    public Team (int pick, String icon, String name, String record, double winPercentage, double gb, String streak, String L10, double top4,  double top1) {
        this.pick = pick;
    	this.icon = icon;
    	this.name = name;
        this.record = record;
        this.winPercentage = winPercentage;
        this.gb = gb;
        this.streak = streak;
        this.L10 = L10;
        this.top4 = top4;
        this.top1 = top1;
        
    }
    
    public int getPick() {
    	return this.pick;
    }
    public String getIcon() {
    	return this.icon;
    }
    public String getName() {
    	return this.name;
    }
    public String getRecord() {
    	return this.record;
    }
    public double getWinPercentage() {
    	return this.winPercentage;
    }
    public double getGB() {
    	return this.gb;
    }
    public String getStreak() {
    	return this.streak;
    }
    public String getL10() {
    	return this.L10;
    }
    public double getTop4() {
    	return this.top4;
    }
    public double getTop1() {
    	return this.top1;
    }
    
}
