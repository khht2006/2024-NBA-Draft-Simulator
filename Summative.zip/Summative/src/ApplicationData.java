
public class ApplicationData {
	static LotterySimulator lotterySimulator; 
	static MockDraft mockDraft;
	static BigBoard bigBoard;
	static PickOdds pickOdds;
	static PastDraftResults pastDraftResults;

}
