import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.AbstractButton;
 
/**
 * This program demonstrates how to sort rows in a table.
 * @author www.codejava.net
 *
 */
public class BigBoard2 extends JFrame {
	private JPanel contentPane;
    private JTable table;
    private JTable table2;
    private JTable table3;
    JCheckBox pg;
    
    public BigBoard2() {
    	//Creating the title and size of the screen
    	setTitle("Big Board");
		setSize(1000, 800);
		setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		//Creating the title of the frame and customizing layout
		JLabel lblNewLabel = new JLabel("2024 NBA Draft Big Board");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
		
		//Filtering players by positions
		pg = new JCheckBox("PG");
		pg.setBounds(8, -8, 50, 50);
		
		

		
		add(pg);
		
		
		//Creating the list of players and the table model
        List<Player> listPlayers = createListPlayers();
        List<Player> listPlayersTier2 = createListPlayersTier2();
        
        PlayerModel playerModel = new PlayerModel(listPlayers);
        PlayerModel playerModelTier2 = new PlayerModel(listPlayersTier2);
        //lblNewLabel.setBackground(Color.white);
        //lblNewLabel.setOpaque(true);
        DefaultTableModel model = new DefaultTableModel();
        DefaultTableModel model2 = new DefaultTableModel();
        
        table = new JTable(playerModel);
        table.getTableHeader().setBackground(Color.RED);
        table.setAutoCreateRowSorter(true);
        
        table2 = new JTable(playerModelTier2);
        table2.getTableHeader().setBackground(Color.GREEN);
        table2.setAutoCreateRowSorter(true);
        
        // Set row height to accommodate larger images
        table.setRowHeight(35); // Adjust the value as needed

        // Set column width to accommodate larger images
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(1).setPreferredWidth(35); // Adjust the value as needed

        
         
        
        //Adding the column titles
        model.addColumn("");
        model.addColumn("");
        model.addColumn("");
        model.addColumn("");
        model.addColumn("");
        model.addColumn("Tier 1");
        model.addColumn("");
        model.addColumn("");
        model.addColumn("");
        model.addColumn("");
        model.addColumn("");
        
        
        
        //Importing the data into the table model
        for (Player player: listPlayers) {
        	model.addRow(new Object[] {
        		player.getRank(), //index 0
        		player.getIcon(),
        		player.getName() + " | " + player.getPosition(),
        		player.getHeight(),
        		player.getWeight() + " lbs",
        		player.getAge() + " yrs | " + player.getCollegeStatus(),
        		player.getPPG() + " PTS",
        		player.getRPG() + " REB",
        		player.getAPG() + " AST",
        		player.getBPG() + " BLK",
        		player.getSPG() + " STL",
        	});
        }
        
        
        
        table.setModel(model);
        table.getColumnModel().getColumn(1).setCellRenderer(new ImageRender());
        
 
        // Sorting the tables
        //Default sorting by the rank of the players
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(table.getModel());

        table.setRowSorter(sorter);
        List<RowSorter.SortKey> sortKeys = new ArrayList<>();
        
       
        //Adding the  ActionListener for the checkboxes
		pg.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean selected = ((AbstractButton) e.getSource()).getModel().isSelected();
				boolean result = false;
				if(selected) {
					TableModel tm = table.getModel();
					int cnt = table.getModel().getRowCount();
					for(int row=0; row<cnt; row++)
					{
							String nameP = (String) tm.getValueAt(row, 2);
							System.out.println("nameP=" + nameP);
							String pos = nameP.substring(nameP.lastIndexOf('|')+1, nameP.length());
							if(nameP.substring(nameP.lastIndexOf('|')+1, nameP.length()).contains("PG")) {
								result = true;
								
							}else {
								result = false;
								//table.remove(2);
							}
					}
				}
			}});
	/*				
				RowFilter<TableModel, Integer> rf = new RowFilter<TableModel, Integer>(){
					@Override
		            public boolean include(RowFilter.Entry<? extends TableModel, ? extends Integer> entry) {
		                // do your logic here to return true or false.
						
						Object isPG = entry.getModel();
		            	if(isPG instanceof Boolean) {
		            		
		            	}
		            	
		            	return result;
		            }
				};
				
				sorter.setRowFilter(rf);
				}
				else {
					sorter.setRowFilter(null);
				}
				*/
			//	};
		 
		 
		
		
        int columnIndexToSort = 0;
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));
         
        sorter.setSortKeys(sortKeys);
        sorter.sort();
        
        
        //Sorting select columns by numbers instead of by strings
        int columnAge = 5;
        int columnPPG = 6;
        int columnRPG = 7;
        int columnAPG = 8;
        int columnBPG = 9;
        int columnSPG = 10;
        
        sorter.setComparator(columnAge, new MixedTypeComparator());
        sorter.setComparator(columnPPG, new MixedTypeComparator());
        sorter.setComparator(columnRPG, new MixedTypeComparator());
        sorter.setComparator(columnAPG, new MixedTypeComparator());
        sorter.setComparator(columnBPG, new MixedTypeComparator());
        sorter.setComparator(columnSPG, new MixedTypeComparator());
        
        
        //Disable sorting of the icons column
    	sorter.setSortable(1, false);
         
        
        
    	//Initialize Screen
//    	JPanel tableContainer = new JPanel();
    	
//    	tableContainer.add(table);
//    	tableContainer.add(table2);
    	
    	JScrollPane scrollTable = new JScrollPane(table);
    	scrollTable.setPreferredSize(new Dimension((int)this.getSize().getWidth(),(int)this.getSize().getHeight()/2));
    	
    	JScrollPane scrollTable2 = new JScrollPane(table2);
    	scrollTable2.setPreferredSize(new Dimension((int)this.getSize().getWidth(),(int)this.getSize().getHeight()/2));
    	
        contentPane.add(scrollTable,BorderLayout.SOUTH);
        //contentPane.add(scrollTable2,BorderLayout.SOUTH);
 
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        
        
        

    }
    
    //Creating lists of players for each tier
    public List<Player> createListPlayers() {
        List<Player> listPlayers = new ArrayList<>();
 
        // Player Data
        Player Ron_Holland = new Player(1, "Resources/gleague.png", 1, "Ron Holland", "SF/PF", "G League", "6-8", 200, "G League", 18.5, 18.0, 6.5, 2.7, 1.0, 2.2);
        Player Alexandre_Sarr = new Player(2, "Resources/france.png", 1, "Alexandre Sarr", "PF/C", "Perth", "7-1", 217, "International", 18.7, 9.8, 4.8, 1.0, 1.2, 0.5);
        Player Nikola_Topic = new Player(3, "Resources/serbia.png", 1, "Nikola Topic", "PG", "Red Star", "6-6", 201, "International", 18.4, 18.5, 3.9, 6.5, 0.1, 1.1);
        Player Matas_Buzelis = new Player(4, "Resources/gleague.png", 1, "Matas Buzelis", "SF", "G League", "6-11", 195, "G League", 19.2, 12.1, 4.8, 1.8, 1.3, 1.1);
        Player Isaiah_Collier = new Player(5, "Resources/usc.png", 1, "Isaiah Collier", "PG", "USC", "6-4", 205, "Freshman", 19.2, 14.9, 2.6, 4.4, 0.2, 1.3);
        
        listPlayers.add(Ron_Holland);
        listPlayers.add(Alexandre_Sarr);
        listPlayers.add(Nikola_Topic);
        listPlayers.add(Matas_Buzelis);
        listPlayers.add(Isaiah_Collier);
        
        return listPlayers;
    }
    
    //Tier 2
    public List<Player> createListPlayersTier2() {
        List<Player> listPlayersTier2 = new ArrayList<>();
 
        // Player Data
        Player Zaccharie_Risacher = new Player(6, "Resources/france.png", 2, "Zaccharie Risacher", "SF", "JL Bourg", "6-8", 200, "International", 18.7, 11.4, 3.7, 1.0, 0.4, 0.9);
        Player p7 = new Player(7, "Resources/france.png", 2, "Alexandre Sarr", "PF/C", "Perth", "7-1", 217, "International", 18.7, 9.8, 4.8, 1.0, 1.2, 0.5);
        Player p8 = new Player(8, "Resources/serbia.png", 2, "Nikola Topic", "PG", "Red Star", "6-6", 201, "International", 18.4, 18.5, 3.9, 6.5, 0.1, 1.1);
        
        listPlayersTier2.add(Zaccharie_Risacher);
        listPlayersTier2.add(p7);
        listPlayersTier2.add(p8);
        return listPlayersTier2;
    }
    
    
    
//    //Method to filter players by position
//    private void Filter(JCheckBox playerPosition, String position, DefaultTableModel model) {
//    	TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
//        table.setRowSorter(sorter);
//
//        List<RowSorter.SortKey> sortKeys = new ArrayList<>();
//        // Additional sorting keys based on selected filters
//        if (playerPosition.isSelected()) {
//            RowFilter<Object, Object> Filter = RowFilter.regexFilter(position, 2);
//            sorter.setRowFilter(Filter);
//        } else {
//            sorter.setRowFilter(null); // Remove any existing filter
//        }
//
//        // Apply the sort keys
//        sorter.setSortKeys(sortKeys);
//        sorter.sort();
//    }
    
    
    
    
    //Displaying the frame
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BigBoard2().setVisible(true);
            }
        });
        
    }
    
    //Displaying the icon images
    public class ImageRender extends DefaultTableCellRenderer {
    	@Override
    	public Component getTableCellRendererComponent (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    		String icon = value.toString();
    		ImageIcon imageIcon = new ImageIcon (new ImageIcon(icon).getImage().getScaledInstance(28, 28, Image.SCALE_DEFAULT));
    		return new JLabel(imageIcon);
    	}
    }
    
    //Handling sorting of the cases where the data contains numbers and string i.e 16.0PTS>9.8PTS
    //Extracting the numeric value of the string
    private static class MixedTypeComparator implements Comparator<Object> {
        @Override
        public int compare(Object o1, Object o2) {
            Double value1 = extractNumericValue(o1.toString());
            Double value2 = extractNumericValue(o2.toString());

            return Double.compare(value1, value2);
        }

        private Double extractNumericValue(String s) {
            // Extract numeric value using a regex
            Pattern pattern = Pattern.compile("\\d+\\.\\d+");
            Matcher matcher = pattern.matcher(s);

            if (matcher.find()) {
                return Double.parseDouble(matcher.group());
            }

            return 0.0;
        }
    }
}
