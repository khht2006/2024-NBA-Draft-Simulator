import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PickOdds extends JFrame {
    private JPanel titlePanel; // Blue panel for the title
    private JPanel titleContentPanel; // Panel to center-align title
    private JLabel titleLabel; // Title label
    private JPanel radioPanel; // Panel for radio buttons
    private JLabel imageLabel; // Image label
    private Color purpleColor = new Color(128, 0, 128);
    private Color yellowColor = new Color(250, 250, 0);

    public PickOdds() {
        setTitle("Pick Odds");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Get the screen dimensions
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        // Set the frame's size to match the screen size
        setSize(screenSize.width-5, screenSize.height-50);
        setLocationRelativeTo(null);

        titlePanel = new JPanel(); // Create a panel for the title
        titlePanel.setLayout(new BorderLayout()); // Use BorderLayout for titlePanel

        titleContentPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Panel to center-align title
        titleLabel = new JLabel("Pick Odds"); // Title label
        titleLabel.setFont(new Font("Tahoma", Font.PLAIN, 30)); // Set font and size
        titleContentPanel.add(titleLabel); // Add the title label to titleContentPanel
        titlePanel.add(titleContentPanel, BorderLayout.NORTH); // Add titleContentPanel to titlePanel's NORTH

        radioPanel = new JPanel(); // Create a panel for radio buttons
        radioPanel.setBackground(purpleColor); 
        radioPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center-align components

        createRadioButtons();

        imageLabel = new JLabel(); // Image label
        imageLabel.setHorizontalAlignment(JLabel.CENTER); // Center alignment

        // Use BorderLayout to position components
        setLayout(new BorderLayout());
        add(titlePanel, BorderLayout.NORTH); // Add the title panel at the top
        add(new JScrollPane(imageLabel), BorderLayout.CENTER); // Add the image label in the center with a vertical scroll pane
    
        
        // Create a menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create a "View" menu
        JMenu viewMenu = new JMenu("More");

        // Create menu items for "Mock Draft" and "Past Draft Results"
        JMenuItem lotterySimulatorMenuItem = new JMenuItem("Lottery Simulator");
        JMenuItem mockDraftMenuItem = new JMenuItem("Mock Draft");
        JMenuItem bigBoardMenuItem = new JMenuItem("Big Board");
        JMenuItem pastDraftResultsMenuItem = new JMenuItem("Past Draft Results");

        // Add action listeners to the menu items
        lotterySimulatorMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openLotterySimulator();
            }
        });
        
        
        mockDraftMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openMockDraft();
            }
        });
        
        
        bigBoardMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openBigBoard();
            }
        });

        pastDraftResultsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Past Draft Results" frame
                openPastDraftResults();
            }
        });

        // Add menu items to the "View" menu
        viewMenu.add(lotterySimulatorMenuItem);
        viewMenu.add(mockDraftMenuItem);
        viewMenu.add(bigBoardMenuItem);
        viewMenu.add(pastDraftResultsMenuItem);

        // Add the "View" menu to the menu bar
        menuBar.add(Box.createHorizontalGlue());
        menuBar.add(viewMenu);

        // Set the menu bar for the JFrame
        setJMenuBar(menuBar);
          
    }
    
    //Run the item selected from the menu
    private void openMockDraft() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.mockDraft == null) {
					ApplicationData.mockDraft = new MockDraft();
					}
				ApplicationData.mockDraft.setVisible(true);
				ApplicationData.pickOdds.setVisible(false);
            }
        });
    }
    //Run the item selected from the menu
    private void openLotterySimulator() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.lotterySimulator == null) {
					ApplicationData.lotterySimulator = new LotterySimulator();
					}
				ApplicationData.lotterySimulator.setVisible(true);
				ApplicationData.pickOdds.setVisible(false);
            }
        });
    }
    //Run the item selected from the menu
    private void openBigBoard() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.bigBoard == null) {
					ApplicationData.bigBoard = new BigBoard();
					}
				ApplicationData.bigBoard.setVisible(true);
				ApplicationData.pickOdds.setVisible(false);
            }
        });
    }
    //Run the item selected from the menu
    private void openPastDraftResults() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.pastDraftResults == null) {
					ApplicationData.pastDraftResults = new PastDraftResults();
					}
				ApplicationData.pastDraftResults.setVisible(true);
				ApplicationData.pickOdds.setVisible(false);
            }
        });
    }
    
    
    //Creating the radio buttons for each of the odds options
    private void createRadioButtons() {
        JRadioButton current = new JRadioButton("Current Odds");
        JRadioButton base = new JRadioButton("Base Odds");
        

        ButtonGroup oddsGroup = new ButtonGroup();
        oddsGroup.add(current);
        oddsGroup.add(base);
     

        radioPanel.add(current);
        radioPanel.add(base);
       

        current.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayDraftResultImage("Resources/pickodds.png");
                radioPanel.setBackground(purpleColor); 
            }
        });

        base.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayDraftResultImage("Resources/baseodds.png");
                radioPanel.setBackground(yellowColor);
            }
        });


        titlePanel.add(radioPanel, BorderLayout.CENTER); // Add the radio panel to titlePanel's CENTER
    }

    private void displayDraftResultImage(String imageName) {
        // Load and display the image based on the selected year
        ImageIcon imageIcon = new ImageIcon(imageName);

        // Resize the image while maintaining its aspect ratio
        int maxWidth = imageLabel.getWidth();
        int maxHeight = imageLabel.getHeight();
        int newWidth = maxWidth;
        int newHeight = (int) (maxWidth / (double) imageIcon.getIconWidth() * imageIcon.getIconHeight());

        if (newHeight > maxHeight) {
            newHeight = maxHeight;
            newWidth = (int) (newHeight / (double) imageIcon.getIconHeight() * imageIcon.getIconWidth());
        }

        // Create a resized image
        Image resizedImage = imageIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);

        // Create a new ImageIcon from the resized image
        ImageIcon resizedIcon = new ImageIcon(resizedImage);

        imageLabel.setIcon(resizedIcon); // Set the resized image as the label's icon
    }
    
    //Displaying the frame
    public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApplicationData.pickOdds = new PickOdds();
					ApplicationData.pickOdds.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
