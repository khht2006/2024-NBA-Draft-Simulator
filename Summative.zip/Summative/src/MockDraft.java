import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

 
/**
 * This program demonstrates how to sort rows in a table.
 * @author www.codejava.net
 *
 */
public class MockDraft extends JFrame {
	//Create contentPane and tables, as well as any items needed throughout
	private JPanel contentPane;
    private JTable table;
    private JTable table2;
    private JTable table3;
    private DefaultTableModel model;
    List<Player> allPlayers = createListPlayers();
	List<Player> sortedPlayers = new ArrayList<>();
	List<JCheckBox> positionCheckboxes = new ArrayList<>();
	private List<Team> teams = createListTeams();
	//Creating the list of players and the table model
    private List<Player> listPlayers = createListPlayers();
    
    
    public MockDraft() {
    	//Creating the title and size of the screen
    	setTitle("2024 NBA Mock Draft");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(100, 100, 450, 300);
		contentPane = new JPanel();	
		contentPane.setPreferredSize(new Dimension(1530, 760));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		//Creating the title of the frame and customizing layout
		JLabel lblNewLabel = new JLabel("2024 NBA Mock Draft");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
        
        
        
        PlayerModel playerModel = new PlayerModel(listPlayers);
        
        //lblNewLabel.setBackground(Color.white);
        //lblNewLabel.setOpaque(true);
        model = new DefaultTableModel();
       
        
        table = new JTable(playerModel);
        table.getTableHeader().setBackground(Color.GREEN);
        table.setAutoCreateRowSorter(true);
        
       
        // Set row height to accommodate larger images
        table.setRowHeight(35); // Adjust the value as needed

        // Set column width to accommodate larger images
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(1).setPreferredWidth(35); // Adjust the value as needed
        

         
        
        //Adding the column titles
        model.addColumn("Selection");
        model.addColumn("Movement");
        model.addColumn("");
        model.addColumn("Tier");
        model.addColumn("Name/Position");
        model.addColumn("Height");
        model.addColumn("Weight");
        model.addColumn("Age/College Status");
        model.addColumn("Points");
        model.addColumn("Rebounds");
        model.addColumn("Assists");
        model.addColumn("Blocks");
        model.addColumn("Steals");
        
        
        
        //Importing the data into the table model
        for (Player player: listPlayers) {
        	model.addRow(new Object[] {
        		player.getRank(),
        		"",
        		teams.get(player.getRank()-1).getIcon(),
        		"<> " + player.getTier(),
        		player.getName() + " | " + player.getPosition(),
        		player.getHeight(),
        		player.getWeight() + " lbs",
        		player.getAge() + " yrs | " + player.getCollegeStatus(),
        		player.getPPG() + " PTS",
        		player.getRPG() + " REB",
        		player.getAPG() + " AST",
        		player.getBPG() + " BLK",
        		player.getSPG() + " STL"	
        	}); 
        }
        
        
        
        table.setModel(model);
        table.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());
         
        
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(sorter);
        List<RowSorter.SortKey> sortKeys = new ArrayList<>();
        
        int columnRank = 0; 
        int columnIndexToSort = 0;
      
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));
        //Making sure the rank is sorted by integers instead of strings
        sorter.setComparator(columnRank, new IntegerComparator());
        
        
        //Disable sorting of all of the columns
    	sorter.setSortable(0, false);
    	sorter.setSortable(1, false);
    	sorter.setSortable(2, false);
    	sorter.setSortable(3, false);
    	sorter.setSortable(4, false);
    	sorter.setSortable(5, false);
    	sorter.setSortable(6, false);
    	sorter.setSortable(7, false);
    	sorter.setSortable(8, false);
    	sorter.setSortable(9, false);
    	sorter.setSortable(10, false);
    	sorter.setSortable(11, false);
    	sorter.setSortable(12, false);
        
        // Create the Simulate button
        JButton simulateButton = new JButton("Simulate Lottery");
        simulateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                simulateLottery();
            }
        });
        
        // Create the Reset button
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadPlayers(listPlayers);
            }
        });
        
        
        // Create a panel to hold the button
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(simulateButton);
        buttonPanel.add(resetButton); // Add the Reset button

        // 
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        
        
 
        add(new JScrollPane(table), BorderLayout.CENTER);
        
        // Create a menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create a "View" menu
        JMenu viewMenu = new JMenu("More");

        // Create menu items for "Mock Draft" and "Past Draft Results"
        JMenuItem lotterySimulatorMenuItem = new JMenuItem("Lottery Simulator");
        JMenuItem bigBoardMenuItem = new JMenuItem("Big Board");
        JMenuItem pickOddsMenuItem = new JMenuItem("Pick Odds");
        JMenuItem pastDraftResultsMenuItem = new JMenuItem("Past Draft Results");

        // Add action listeners to the menu items
        lotterySimulatorMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openLotterySimulator();
            }
        });
        
        
        pickOddsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
            	openPickOdds();
            }
        });
        
        
        bigBoardMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Mock Draft" frame
                openBigBoard();
            }
        });

        pastDraftResultsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call a method to open the "Past Draft Results" frame
                openPastDraftResults();
            }
        });

        // Add menu items to the "View" menu
        viewMenu.add(lotterySimulatorMenuItem);
        viewMenu.add(bigBoardMenuItem);
        viewMenu.add(pickOddsMenuItem);
        viewMenu.add(pastDraftResultsMenuItem);

        // Add the "View" menu to the menu bar
        menuBar.add(Box.createHorizontalGlue());
        menuBar.add(viewMenu);

        // Set the menu bar for the JFrame
        setJMenuBar(menuBar);
        
        
        
 
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
      
        

    }
    
    //Creating lists of players for each tier
    public List<Player> createListPlayers() {
        List<Player> listPlayers = new ArrayList<>();
 
        // Player Data
        Player Alexandre_Sarr = new Player(1, "Resources/france.png", 1, "Alexandre Sarr", "PF/C", "Perth", "7-1", 217, "International", 18.7, 18.7, 9.1, 2.0, 2.4, 0.9);
        Player Nikola_Topic = new Player(2, "Resources/serbia.png", 1, "Nikola Topic", "PG", "Red Star", "6-6", 201, "International", 18.4, 19.1, 4.2, 7.1, 0.2, 1.1);
        Player Zaccharie_Risacher = new Player(3, "Resources/france.png", 1, "Zaccharie Risacher", "SF", "JL Bourg", "6-9", 204, "International", 18.7, 18.0, 5.8, 1.6, 0.7, 1.5);
        Player JaKobe_Walter = new Player(4, "Resources/baylor.png", 1, "Ja'Kobe Walter", "SG", "Baylor", "6-5", 180, "Freshman", 19.3, 20.5, 5.5, 2.1, 0.2, 1.7);
        Player Ron_Holland = new Player(5, "Resources/gleague.png", 1, "Ron Holland", "SF/PF", "G League", "6-8", 200, "G League", 18.5, 20.9, 7.7, 3.1, 1.1, 2.6);
        Player Matas_Buzelis = new Player(6, "Resources/gleague.png", 1, "Matas Buzelis", "SF", "G League", "6-11", 195, "G League", 19.2, 16.0, 6.6, 2.2, 1.8, 1.5);
        Player Reed_Sheppard = new Player(7, "Resources/kentucky.png", 2, "Reed Sheppard", "PG/SG", "Kentucky", "6-3", 187, "Freshman", 19.5, 17.1, 6.4, 5.9, 1.3, 3.8);
        Player Rob_Dillingham = new Player(8, "Resources/kentucky.png", 2, "Rob Dillingham", "PG", "Kentucky", "6-3", 176, "Freshman", 19.0, 22.4, 6.0, 7.0, 0.1, 2.5);
        Player Isaiah_Collier = new Player(9, "Resources/usc.png", 2, "Isaiah Collier", "PG", "USC", "6-4", 205, "Freshman", 19.3, 19.3, 3.2, 5.4, 0.2, 1.6);
        Player Cody_Williams = new Player(10, "Resources/colorado.png", 2, "Cody Williams", "SF", "Colorado", "6-8", 185, "Freshman", 19.1, 18.0, 4.6, 2.6, 0.4, 1.1);
        Player Donovan_Clingan = new Player(11, "Resources/uconn.png", 2, "Donovan Clingan", "C", "UConn", "7-2", 265, "Sophomore", 19.9, 24.2, 10.9, 2.2, 3.5, 0.9);
        Player Stephon_Castle = new Player(12, "Resources/uconn.png", 3, "Stephon Castle", "PG/SG", "UConn", "6-6", 190, "Freshman", 19.2, 15.1, 7.4, 5.3, 0.9, 1.8);
        Player Kyle_Filipowski = new Player(13, "Resources/duke.png", 3, "Kyle Filipowski", "C", "Duke", "7-0", 248, "Sophomore", 20.2, 21.4, 10.6, 3.6, 2.4, 1.5);
        Player Tidjane_Salaun = new Player(14, "Resources/france.png", 3, "Tidjane Salaun", "SF", "Cholet Basket", "6-9", 203, "International", 18.4, 15.1, 5.1, 1.3, 0.3, 2.1);
        
        
        
        //Adding players to the player list
        listPlayers.add(Alexandre_Sarr);
        listPlayers.add(Nikola_Topic);
        listPlayers.add(Zaccharie_Risacher);
        listPlayers.add(JaKobe_Walter);
        listPlayers.add(Ron_Holland);
        listPlayers.add(Matas_Buzelis);
        listPlayers.add(Reed_Sheppard);
        listPlayers.add(Rob_Dillingham);
        listPlayers.add(Isaiah_Collier);
        listPlayers.add(Cody_Williams);
        listPlayers.add(Donovan_Clingan);
        listPlayers.add(Stephon_Castle);
        listPlayers.add(Kyle_Filipowski);
        listPlayers.add(Tidjane_Salaun);

        
        return listPlayers;
    }
   
    //Method to load the players back into the table
    private void loadPlayers(List<Player> Players) {
    	model.getDataVector().clear();
    	model.fireTableDataChanged();
    	
    	for (Player player: Players) {
        	model.addRow(new Object[] {
        		player.getRank(),
        		"",
        		teams.get(player.getRank()-1).getIcon(),
        		"<> " + player.getTier(),
        		player.getName() + " | " + player.getPosition(),
        		player.getHeight(),
        		player.getWeight() + " lbs",
        		player.getAge() + " yrs | " + player.getCollegeStatus(),
        		player.getPPG() + " PTS",
        		player.getRPG() + " REB",
        		player.getAPG() + " AST",
        		player.getBPG() + " BLK",
        		player.getSPG() + " STL",
        		
        	});
        }
    	
    	table.setModel(model);
        table.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());
        
        
    }
    
    
    
    
    //Displaying the frame
    public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApplicationData.mockDraft = new MockDraft();
					ApplicationData.mockDraft.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
    
    
    //Method to run the item selected from the menu
    private void openLotterySimulator() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.lotterySimulator == null) {
					ApplicationData.lotterySimulator = new LotterySimulator();
					}
				ApplicationData.lotterySimulator.setVisible(true);
				ApplicationData.mockDraft.setVisible(false);
            }
        });
    }
    
    //Method to run the item selected from the menu
    private void openBigBoard() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.bigBoard == null) {
					ApplicationData.bigBoard = new BigBoard();
					}
				ApplicationData.bigBoard.setVisible(true);
				ApplicationData.mockDraft.setVisible(false);
            }
        });
    }
    
    //Method to run the item selected from the menu
    private void openPickOdds() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.pickOdds == null) {
					ApplicationData.pickOdds = new PickOdds();
					}
				ApplicationData.pickOdds.setVisible(true);
				ApplicationData.mockDraft.setVisible(false);
            }
        });
    }
    
    //Method to run the item selected from the menu
    private void openPastDraftResults() {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if (ApplicationData.pastDraftResults == null) {
					ApplicationData.pastDraftResults = new PastDraftResults();
					}
				ApplicationData.pastDraftResults.setVisible(true);
				ApplicationData.mockDraft.setVisible(false);
            }
        });
    }
    
    //Displaying the icon images
    public class ImageRender extends DefaultTableCellRenderer {
    	@Override
    	public Component getTableCellRendererComponent (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    		String icon = value.toString();
    		ImageIcon imageIcon = new ImageIcon (new ImageIcon(icon).getImage().getScaledInstance(28, 28, Image.SCALE_DEFAULT));
    		return new JLabel(imageIcon);
    	}
    }
    
    //Simulating the lottery process
    private void simulateLottery() {
	  	List <Team> randomTeams = randomLottery();
	  	model.getDataVector().clear();
	  	model.fireTableDataChanged();
	  	//calculating any movement within the lottery
	  	for (Team team: randomTeams) {
	  		
	  		String pickSymbol;
	  		
	  	    int pickDifference = team.getPick() - (randomTeams.indexOf(team) + 1);
	
	  	    if (pickDifference > 0) {
	  	        pickSymbol = "\u2191"; // Better pick than seed
	  	    } else if (pickDifference < 0) {
	  	        pickSymbol = "\u2193"; // Worse pick than seed
	  	    } else {
	  	        pickSymbol = "-"; // Same pick as seed
	  	    }
	  	    
	  	    Player player = listPlayers.get(randomTeams.indexOf(team));
	  	    //Load the selected teams into the right positions
	  	    model.addRow(new Object[] {
	        		player.getRank(),
	        		pickSymbol + " " + (pickSymbol.equals("-") ? "-" : Math.abs(pickDifference)), // Display the difference as a positive number
	        		randomTeams.get(player.getRank()-1).getIcon(),
	        		"<> " + player.getTier(),
	        		player.getName() + " | " + player.getPosition(),
	        		player.getHeight(),
	        		player.getWeight() + " lbs",
	        		player.getAge() + " yrs | " + player.getCollegeStatus(),
	        		player.getPPG() + " PTS",
	        		player.getRPG() + " REB",
	        		player.getAPG() + " AST",
	        		player.getBPG() + " BLK",
	        		player.getSPG() + " STL"
	       	
	      });
	  	
	       
	       table.setModel(model);
	       table.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());
	  }
    }
    
    
    //Distribute the picks to the lottery teams randomly
    public List<Team> randomLottery() {
    		HashMap<Integer, Team> top4ToTeam = new HashMap();
    		Integer count = 0;
    		List<Integer> allData = new ArrayList<>();
    		List<Team> randomTeams = new ArrayList<>();
    		
    		for(Team team: teams) {
    			top4ToTeam.put(count, team);
    			for(int i = 0; i<team.getTop1()*10; i++) {
    				allData.add(count);
    			}
    			count++;
    		}
    		Random rand = new Random();
    		for(int i = 0; i<4; i++) {
    			int randIndex = rand.nextInt(allData.size());
    			int numAtRand = allData.get(randIndex);
    			Team pickedTeam = top4ToTeam.get(numAtRand);
    			randomTeams.add(pickedTeam);
    			allData.removeAll(List.of(numAtRand));
    		}
    		for(Team team: teams) {
    			if(!randomTeams.contains(team)) {
    				randomTeams.add(team);
    			}
    		}
            return randomTeams;
    }
    
    
  //Creating the list of teams
    public List<Team> createListTeams() {
        List<Team> listTeams = new ArrayList<>();
 
        // Team Data
        Team Detroit = new Team(1, "Resources/detroit.png", "Detroit", "3-33", 0.083, 0, "Lost 4", "1-9", 52.1, 14.0);
        Team San_Antonio = new Team(2, "Resources/sanAntonio.png", "San Antonio", "5-30", 0.143, 2.5, "Lost 5", "1-9", 52.1, 14.0);
        Team Washington = new Team(3, "Resources/washington.png", "Washington", "6-29", 0.171, 3.5, "Lost 4", "2-8", 52.1, 14.0);
        Team Charlotte = new Team(4, "Resources/charlotte.png", "Charlotte", "8-25", 0.242, 6.5, "Lost 1", "1-9", 48.1, 12.5);
        Team Portland = new Team(5, "Resources/portland.png", "Portland", "10-25", 0.286, 7.5, "Won 1", "4-6", 42.1, 10.5);
        Team Memphis = new Team(6, "Resources/memphis.png", "Memphis", "13-23", 0.361, 10.0, "Won 2", "6-4", 37.2, 9.0);
        Team Atlanta = new Team(7, "Resources/atlanta.png", "Atlanta", "14-21", 0.400, 11.5, "Lost 2", "4-6", 31.9, 7.5);
        Team Toronto = new Team(8, "Resources/toronto.png", "Toronto", "15-21", 0.417, 12.0, "Won 1", "4-6", 26.3, 6.0);
        Team Brooklyn = new Team(9, "Resources/brooklyn.png", "Brooklyn", "16-21", 0.432, 12.5, "Lost 1", "3-7", 17.3, 3.8);
        Team Chicago = new Team(10, "Resources/chicago.png", "Chicago", "16-21", 0.432, 12.5, "Won 1", "6-4", 16.9, 3.7);
        Team Utah = new Team(11, "Resources/utah.png", "Utah", "17-20", 0.459, 13.5, "Won 1", "7-3", 9.4, 2.0);
        Team Golden_State = new Team(12, "Resources/goldenState.png", "Golden State", "17-19", 0.472, 14.0, "Lost 1", "5-5", 7.1, 1.5);
        Team Los_Angeles_Lakers = new Team(13, "Resources/losAngelesLakers.png", "Los Angeles Lakers", "18-19", 0.486, 14.5, "Won 1", "3-7", 4.8, 1.0);
        Team Phoenix = new Team(14, "Resources/phoenix.png", "Phoenix", "19-17", 0.528, 16.0, "Lost 1", "5-5", 2.4, 0.5);
        
        
        //Adding Teams to the Team list
        listTeams.add(Detroit);
        listTeams.add(San_Antonio);
        listTeams.add(Washington);
        listTeams.add(Charlotte);
        listTeams.add(Portland);
        listTeams.add(Memphis);
        listTeams.add(Atlanta);
        listTeams.add(Toronto);
        listTeams.add(Brooklyn);
        listTeams.add(Chicago);
        listTeams.add(Utah);
        listTeams.add(Golden_State);
        listTeams.add(Los_Angeles_Lakers);
        listTeams.add(Phoenix);
        
        return listTeams;
    }
    
    
    //Comparing integer values instead of string values
    public class IntegerComparator implements Comparator<Object> {
        @Override
        public int compare(Object o1, Object o2) {
            Integer value1 = extractIntegerValue(o1.toString());
            Integer value2 = extractIntegerValue(o2.toString());

            return Integer.compare(value1, value2);
        }

        private Integer extractIntegerValue(String s) {
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                return 0; // Return 0 if parsing fails
            }
        }
    }

    
    
}
